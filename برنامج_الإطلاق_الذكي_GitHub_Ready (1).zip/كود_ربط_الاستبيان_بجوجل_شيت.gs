/*
كود Google Apps Script لحفظ نتائج الاستبيان في Google Sheets

الخطوات:
1) افتح Google Sheet جديد.
2) من الشيت: Extensions > Apps Script.
3) احذف أي كود موجود والصق هذا الكود.
4) ضع رقم ملف الشيت بين علامتي التنصيص في SPREADSHEET_ID.
   رقم الشيت هو الجزء الموجود في الرابط بين /d/ و /edit
5) اضغط Deploy > New deployment > Web app.
6) Execute as: Me
7) Who has access: Anyone
8) انسخ Web app URL.
9) افتح ملف survey/index.html وابحث عن:
   const WEB_APP_URL = "..."
   واستبدل الرابط برابط Web app URL الجديد.
*/

const SPREADSHEET_ID = "PUT_YOUR_SPREADSHEET_ID_HERE";
const SHEET_NAME = "responses";

function doGet(e) {
  return ContentService
    .createTextOutput("Google Sheet endpoint is working")
    .setMimeType(ContentService.MimeType.TEXT);
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  try {
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sheet = ss.getSheetByName(SHEET_NAME);
    if (!sheet) sheet = ss.insertSheet(SHEET_NAME);

    const data = JSON.parse(e.postData.contents || "{}");

    const headers = [
      "timestamp",
      "name",
      "phone",
      "email",
      "type",
      "status",
      "idea",
      "score",
      "level",
      "strengths",
      "improvements",
      "need",
      "summary",
      "pageUrl"
    ];

    if (sheet.getLastRow() === 0) {
      sheet.appendRow(headers);
    }

    sheet.appendRow(headers.map(function(key) {
      if (key === "timestamp") return new Date();
      return data[key] || "";
    }));

    return ContentService
      .createTextOutput(JSON.stringify({ ok: true }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: String(err) }))
      .setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}